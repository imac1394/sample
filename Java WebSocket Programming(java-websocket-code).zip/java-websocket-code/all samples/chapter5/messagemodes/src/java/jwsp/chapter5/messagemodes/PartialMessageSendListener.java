
package jwsp.chapter5.messagemodes;


public interface PartialMessageSendListener {
    
    public void reportProgress(int i);
    
}
