package jwsp.chapter6.portfolio;

public class UnknownMemberLevelException extends RuntimeException {
    
    public UnknownMemberLevelException(String message) {
        super(message);
    }
    
}
