package jwsp.chapter6.portfolio;

public interface StockDataSourceListener {
    
    public void handleNewStockData(PortfolioUpdate pu);
    
}
