/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jwsp.chapter3.drawing.data;

/**
 *
 * @author dannycoward
 */
public class FakeDecoder {
    
    
    
    
}
